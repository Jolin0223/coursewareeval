(function () {
    // 1. 1920x1080 画布等比例缩放逻辑
    var app = document.getElementById('app');
    function updateScale() {
        var s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
        app.style.transform = 'translate(-50%, -50%) scale(' + s + ')';
        app.style.visibility = 'visible';
    }
    window.addEventListener('resize', updateScale);
    updateScale();

    // 2. 定义题目数据
    var questions = [
        { text: "请选出所有的偶数", options: [2, 3, 4], answers: [2, 4], audioId: 'audio-q1' },
        { text: "请选出所有的奇数", options: [1, 5, 6], answers: [1, 5], audioId: 'audio-q2' }
    ];

    // 3. 状态管理
    var currentQuestionIndex = 0;
    var selectedOptions = [];
    var isSubmitted = false;
    var isCorrect = false;
    var totalScore = 0;
    var retryCount = 0;
    var currentAudio = null;

    // DOM 元素
    var questionTextEl = document.getElementById('question-text');
    var optionCards = document.querySelectorAll('.option-card');
    var submitBtn = document.getElementById('submit-btn');
    var nextBtn = document.getElementById('next-btn');
    var resultPanel = document.getElementById('result-panel');
    var retryBtn = document.getElementById('retry-btn');
    var progress1 = document.getElementById('progress-1').querySelector('.cb-icon');
    var progress2 = document.getElementById('progress-2').querySelector('.cb-icon');

    // Web Audio API 音效
    var AudioContext = window.AudioContext || window.webkitAudioContext;
    var audioCtx = new AudioContext();

    function playTone(type) {
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
        var osc = audioCtx.createOscillator();
        var gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);

        var now = audioCtx.currentTime;
        if (type === 'click') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(600, now);
            osc.frequency.exponentialRampToValueAtTime(300, now + 0.1);
            gain.gain.setValueAtTime(0.3, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
            osc.start(now);
            osc.stop(now + 0.1);
        } else if (type === 'success') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(400, now);
            osc.frequency.setValueAtTime(600, now + 0.1);
            osc.frequency.setValueAtTime(800, now + 0.2);
            gain.gain.setValueAtTime(0.3, now);
            gain.gain.linearRampToValueAtTime(0, now + 0.4);
            osc.start(now);
            osc.stop(now + 0.4);
        } else if (type === 'fail') {
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(300, now);
            osc.frequency.linearRampToValueAtTime(200, now + 0.3);
            gain.gain.setValueAtTime(0.3, now);
            gain.gain.linearRampToValueAtTime(0, now + 0.3);
            osc.start(now);
            osc.stop(now + 0.3);
        }
    }

    // 播放语音
    function playAudio(id) {
        if (currentAudio) {
            currentAudio.pause();
            currentAudio.currentTime = 0;
        }
        var audioEl = document.getElementById(id);
        if (audioEl) {
            var playPromise = audioEl.play();
            if (playPromise !== undefined) {
                playPromise.catch(function(error) {
                    console.log("Audio play prevented: ", error);
                });
            }
            currentAudio = audioEl;
        }
    }

    // 加载题目
    function loadQuestion() {
        var q = questions[currentQuestionIndex];
        questionTextEl.textContent = q.text;
        selectedOptions = [];
        isSubmitted = false;
        isCorrect = false;

        for (var i = 0; i < optionCards.length; i++) {
            var card = optionCards[i];
            card.classList.remove('selected');
            card.querySelector('.option-number').textContent = q.options[i];
            var icon = card.querySelector('.feedback-icon');
            icon.style.display = 'none';
            icon.className = 'feedback-icon cb-icon';
        }

        submitBtn.style.display = 'flex';
        nextBtn.style.display = 'none';

        playAudio(q.audioId);
    }

    // 4. 交互逻辑：卡片点击
    for (var i = 0; i < optionCards.length; i++) {
        (function(index) {
            var card = optionCards[index];
            card.addEventListener('pointerdown', function(e) {
                if (isCorrect) return; // 答对后不可修改

                var q = questions[currentQuestionIndex];
                var val = q.options[index];
                var idx = selectedOptions.indexOf(val);

                if (idx > -1) {
                    selectedOptions.splice(idx, 1);
                    card.classList.remove('selected');
                } else {
                    selectedOptions.push(val);
                    card.classList.add('selected');
                }

                playTone('click');

                // 隐藏之前的错误反馈
                var icon = card.querySelector('.feedback-icon');
                icon.style.display = 'none';
            });
        })(i);
    }

    // 5. 提交逻辑
    submitBtn.addEventListener('click', function() {
        if (isCorrect) return;
        var q = questions[currentQuestionIndex];
        var correctAnswers = q.answers;

        var isAllCorrect = true;
        if (selectedOptions.length !== correctAnswers.length) {
            isAllCorrect = false;
        } else {
            for (var i = 0; i < correctAnswers.length; i++) {
                if (selectedOptions.indexOf(correctAnswers[i]) === -1) {
                    isAllCorrect = false;
                    break;
                }
            }
        }

        isSubmitted = true;

        if (isAllCorrect) {
            isCorrect = true;
            totalScore += 1;
            playTone('success');

            for (var j = 0; j < optionCards.length; j++) {
                var card = optionCards[j];
                var val = q.options[j];
                if (selectedOptions.indexOf(val) > -1) {
                    var icon = card.querySelector('.feedback-icon');
                    icon.className = 'feedback-icon cb-icon cb-icon-correct';
                    icon.style.display = 'block';
                }
            }

            if (currentQuestionIndex === 0) {
                progress1.className = 'cb-icon cb-icon-star';
            } else {
                progress2.className = 'cb-icon cb-icon-star';
            }

            submitBtn.style.display = 'none';
            nextBtn.style.display = 'flex';
        } else {
            retryCount += 1;
            playTone('fail');

            for (var k = 0; k < optionCards.length; k++) {
                var cardErr = optionCards[k];
                var valErr = q.options[k];
                if (selectedOptions.indexOf(valErr) > -1) {
                    var iconErr = cardErr.querySelector('.feedback-icon');
                    iconErr.className = 'feedback-icon cb-icon cb-icon-incorrect';
                    iconErr.style.display = 'block';
                }
            }
        }
    });

    // 6. 切题逻辑
    nextBtn.addEventListener('click', function() {
        if (currentQuestionIndex === 0) {
            currentQuestionIndex++;
            loadQuestion();
        } else {
            // 7. 结算逻辑
            showResult();
        }
    });

    function showResult() {
        resultPanel.style.display = 'flex';
        playAudio('audio-finish');

        // 9. 数据上报
        if (window.kpmSdk && typeof window.kpmSdk.reportGameResult === 'function') {
            var accuracy = Math.round((totalScore / questions.length) * 100);
            try {
                window.kpmSdk.reportGameResult({
                    total_score: totalScore,
                    accuracy: accuracy,
                    completed_task_count: questions.length,
                    retry_count: retryCount
                });
            } catch (e) {
                console.error("Report failed", e);
            }
        }
    }

    // 重新练习
    retryBtn.addEventListener('click', function() {
        resultPanel.style.display = 'none';
        currentQuestionIndex = 0;
        totalScore = 0;
        retryCount = 0;
        progress1.className = 'cb-icon cb-icon-star-empty';
        progress2.className = 'cb-icon cb-icon-star-empty';
        loadQuestion();
    });

    // 初始化
    window.addEventListener('DOMContentLoaded', function() {
        if (window.kpmSdk && typeof window.kpmSdk.startGame === 'function') {
            try {
                window.kpmSdk.startGame();
            } catch (e) {
                console.error("Start game report failed", e);
            }
        }
        // 需用户交互才能播放音频，这里尝试加载
        loadQuestion();
    });

})();