# 静音图标优化 · 2.1.2-css

静音图标改为“喇叭＋叉号”，去掉容易误认成声波的分离斜杠。保留圆润喇叭、圆头笔画和现有按钮底座。

## 开发接入

- 将本包 `icon.css` 原样替换到当前业务资源地址 `https://oss-xlss.xdf.cn/ig-kpm/resources/standard-icon.css`，注意目标文件名为 `standard-icon.css`。上传后刷新 CDN 缓存。
- 类名仍为 `cb-icon-mute`，无需修改 HTML 或系统提示词；保留其余 15 个图标及所有按钮尺寸、颜色和交互规则。
- 三套预设主题及自定义颜色仍由 `currentColor` 控制。
- 本次仅更新评审站预览，业务 CDN 由开发上传；不将预览部署视为业务部署。

## 历史课件

引用上述公共 CSS 的课件会在缓存更新后显示新图标；本地打包 CSS 或内嵌旧样式的历史课件继续显示旧图标且不影响运行。如需统一外观，替换各包 CSS 后重新打包即可，不需要调整静音逻辑。

预览：https://coursewareeval.chenjialing.cn/icon-font-review/demo/?v=2.1.2
